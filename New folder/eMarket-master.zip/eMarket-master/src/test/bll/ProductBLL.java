//package test.bll;
//
//import test.entity.Product;
//
//import javax.naming.Context;
//import javax.naming.InitialContext;
//import javax.sql.DataSource;
//import java.sql.Connection;
//import java.sql.ResultSet;
//import java.sql.Statement;
//import java.util.ArrayList;
//import java.util.List;
//
//public class ProductBLL {
//  //  @Resource(name = "jdbc/eMarket")
//  //  private DataSource ds;
//    public ProductBLL() {
//    }
//
//    public List<Product> getNewProducts(int number) {
//        try {
//            Context initContext = new InitialContext();
//            DataSource ds = (DataSource) initContext.lookup("java:comp/env/jdbc/eMarket");
//            Connection conn = ds.getConnection();
//            Statement sttm = conn.createStatement();
//            String sql = "select * from product";
//            ResultSet rs = sttm.executeQuery(sql);
//            ArrayList<Product> prods = new ArrayList<>();
//            int dem = 0 ;
//            while(rs.next() && dem < number) {
//                Product p = new Product();
//                p.setProductID(rs.getInt("product_id"));
//                p.setCategoryID(rs.getInt("category_id"));
//                p.setPrice(rs.getFloat("price"));
//                p.setDescription(rs.getString("description"));
//                p.setImage(rs.getString("image"));
//                p.setName(rs.getString("name"));
//                p.setThumbImage(rs.getString("thumb_image"));
//                p.setLastUpdate(rs.getDate("last_update"));
//                p.setDescriptionDetail(rs.getString("description_detail"));
//                prods.add(p);
//                dem++;
//            }
//
//            return prods;
//        } catch (Exception var8) {
//            var8.printStackTrace();
//            return null;
//        }
//    }
//}
