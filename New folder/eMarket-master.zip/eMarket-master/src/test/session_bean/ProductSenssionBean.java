package test.session_bean;

import test.entity.ProductEntity;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class ProductSenssionBean extends AbstractSessionBean{
    @PersistenceContext(unitName = "NewPersistenceUnit")
    private EntityManager em ;

    protected EntityManager getEntityManager(){
        return em;
    }
    public ProductSenssionBean(){
        super(ProductEntity.class);
    }
}
