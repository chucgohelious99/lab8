//package test;
//
//import test.bll.ProductBLL;
//
//import java.util.List;
//
//public class test {
//    public static List<Product>  lists;
//
//    public static void main(String[] args) {
//        lists=  new ProductBLL().getNewProducts(5);
//        System.out.println(lists.toString());
//    }
//}
